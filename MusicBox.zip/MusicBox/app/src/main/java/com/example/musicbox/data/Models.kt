package com.example.musicbox.data

import androidx.room.*

@Entity(tableName = "songs")
data class SongEntity(
    @PrimaryKey val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val uri: String,
    val duration: Long,
    val favorite: Boolean = false,
    val lastPlayed: Long = 0L
)

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

@Entity(primaryKeys = ["playlistId", "songId"])
data class PlaylistSongCrossRef(val playlistId: Long, val songId: Long)

data class PlaylistWithSongs(
    @Embedded val playlist: PlaylistEntity,
    @Relation(parentColumn = "id", entityColumn = "id", associateBy = Junction(
        value = PlaylistSongCrossRef::class,
        parentColumn = "playlistId",
        entityColumn = "songId"
    )) val songs: List<SongEntity>
)

@Dao
interface MusicDao {
    @Query("SELECT * FROM songs ORDER BY title COLLATE NOCASE")
    fun observeSongs(): kotlinx.coroutines.flow.Flow<List<SongEntity>>

    @Query("SELECT * FROM songs WHERE favorite = 1 ORDER BY title COLLATE NOCASE")
    fun observeFavorites(): kotlinx.coroutines.flow.Flow<List<SongEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSongs(songs: List<SongEntity>)

    @Query("UPDATE songs SET favorite = :favorite WHERE id = :songId")
    suspend fun setFavorite(songId: Long, favorite: Boolean)

    @Query("UPDATE songs SET lastPlayed = :time WHERE id = :songId")
    suspend fun markPlayed(songId: Long, time: Long)

    @Query("SELECT * FROM playlists ORDER BY name COLLATE NOCASE")
    fun observePlaylists(): kotlinx.coroutines.flow.Flow<List<PlaylistEntity>>

    @Insert
    suspend fun createPlaylist(playlist: PlaylistEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun addSongToPlaylist(ref: PlaylistSongCrossRef)

    @Query("SELECT * FROM songs WHERE id IN (SELECT songId FROM PlaylistSongCrossRef WHERE playlistId = :playlistId) ORDER BY title")
    fun observePlaylistSongs(playlistId: Long): kotlinx.coroutines.flow.Flow<List<SongEntity>>
}

@Database(entities = [SongEntity::class, PlaylistEntity::class, PlaylistSongCrossRef::class], version = 1, exportSchema = false)
abstract class MusicDatabase : RoomDatabase() {
    abstract fun musicDao(): MusicDao
    companion object {
        @Volatile private var INSTANCE: MusicDatabase? = null
        fun get(context: android.content.Context): MusicDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, MusicDatabase::class.java, "musicbox.db").build().also { INSTANCE = it }
        }
    }
}
