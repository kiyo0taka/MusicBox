
package com.example.musicbox

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.Player
import com.example.musicbox.data.*
import com.example.musicbox.player.PlayerController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF0D0B16)
private val SurfaceDark = Color(0xFF1B1728)
private val SurfaceLight = Color(0xFF252036)
private val Purple = Color(0xFFAC7BFF)
private val PurpleDark = Color(0xFF7046C7)
private val Muted = Color(0xFFAAA4B9)
private val White = Color(0xFFF8F5FF)

class MainActivity : ComponentActivity() {

    private lateinit var db: MusicDatabase
    private lateinit var controller: PlayerController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        db = MusicDatabase.get(this)
        controller = PlayerController(this)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Purple,
                    background = Bg,
                    surface = SurfaceDark,
                    onBackground = White,
                    onSurface = White
                )
            ) {
                MusicBoxApp(db, controller)
            }
        }
    }

    override fun onDestroy() {
        controller.release()
        super.onDestroy()
    }
}

@Composable
private fun MusicBoxApp(
    db: MusicDatabase,
    controller: PlayerController
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val dao = remember { db.musicDao() }

    val songs by dao.observeSongs().collectAsState(initial = emptyList())
    val favorites by dao.observeFavorites().collectAsState(initial = emptyList())
    val playlists by dao.observePlaylists().collectAsState(initial = emptyList())

    var selectedTab by remember { mutableStateOf("Библиотека") }
    var selectedPlaylist by remember { mutableStateOf<PlaylistEntity?>(null) }
    var query by remember { mutableStateOf("") }

    var currentIndex by remember { mutableIntStateOf(-1) }
    var isPlaying by remember { mutableStateOf(false) }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }

    val activeQueue = remember { mutableStateListOf<SongEntity>() }

    var showCreatePlaylist by remember { mutableStateOf(false) }
    var playlistName by remember { mutableStateOf("") }
    var showAddToPlaylist by remember { mutableStateOf<SongEntity?>(null) }

    var scanMessage by remember {
        mutableStateOf("Разреши доступ к аудиофайлам, чтобы загрузить музыку")
    }

    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_AUDIO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    fun scanLibrary() {
        (context as? ComponentActivity)?.lifecycleScope?.launch {
            val found = withContext(Dispatchers.IO) {
                AudioScanner.scan(context)
            }

            withContext(Dispatchers.IO) {
                dao.upsertSongs(found)
            }

            scanMessage = if (found.isEmpty()) {
                "Музыкальные файлы не найдены"
            } else {
                "Найдено композиций: ${found.size}"
            }
        }
    }

    val permissionLauncher =
        rememberLauncherForActivityResult(
            ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) {
                scanLibrary()
            } else {
                scanMessage = "Нет разрешения на чтение музыки"
            }
        }

    LaunchedEffect(Unit) {
        if (
            ContextCompat.checkSelfPermission(context, permission) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            scanLibrary()
        } else {
            permissionLauncher.launch(permission)
        }
    }

    DisposableEffect(controller.player) {
        val listener = object : Player.Listener {

            override fun onIsPlayingChanged(playing: Boolean) {
                isPlaying = playing
            }

            override fun onMediaItemTransition(
                mediaItem: androidx.media3.common.MediaItem?,
                reason: Int
            ) {
                currentIndex = controller.player.currentMediaItemIndex
                duration = controller.player.duration.coerceAtLeast(0L)
            }
        }

        controller.player.addListener(listener)

        onDispose {
            controller.player.removeListener(listener)
        }
    }

    LaunchedEffect(isPlaying, currentIndex) {
        while (isPlaying) {
            position = controller.player.currentPosition.coerceAtLeast(0L)
            duration = controller.player.duration.coerceAtLeast(0L)
            delay(500)
        }
    }

    val visibleSongs = when (selectedTab) {
        "Избранное" -> favorites
        else -> songs
    }.filter {
        it.title.contains(query, true) ||
                it.artist.contains(query, true) ||
                it.album.contains(query, true)
    }

    val playlistSongsFlow = remember(selectedPlaylist?.id) {
        selectedPlaylist?.let {
            dao.observePlaylistSongs(it.id)
        } ?: flowOf<List<SongEntity>>(emptyList())
    }

    val playlistSongs by playlistSongsFlow.collectAsState(
        initial = emptyList()
    )

    val openedPlaylist = selectedPlaylist
    val currentSong = activeQueue.getOrNull(currentIndex)

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            Column(
                Modifier.background(Bg)
            ) {
                if (currentSong != null) {
                    MiniPlayer(
                        song = currentSong,
                        playing = isPlaying,
                        position = position,
                        duration = duration,
                        onPlayPause = {
                            if (controller.player.isPlaying) {
                                controller.player.pause()
                            } else {
                                controller.player.play()
                            }
                        },
                        onNext = {
                            controller.player.seekToNextMediaItem()
                        },
                        onOpen = {
                            selectedTab = "Сейчас играет"
                        }
                    )
                }

                NavigationBar(
                    containerColor = Color(0xFF171322),
                    contentColor = White,
                    tonalElevation = 0.dp
                ) {
                    listOf(
                        Triple("Библиотека", Icons.Default.LibraryMusic, "Музыка"),
                        Triple("Избранное", Icons.Default.Favorite, "Любимое"),
                        Triple("Плейлисты", Icons.Default.QueueMusic, "Подборки")
                    ).forEach { (label, icon, text) ->

                        NavigationBarItem(
                            selected = selectedTab == label,
                            onClick = {
                                selectedTab = label
                                selectedPlaylist = null
                            },
                            icon = {
                                Icon(icon, null)
                            },
                            label = {
                                Text(text, fontSize = 10.sp)
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Purple,
                                indicatorColor = Purple.copy(alpha = 0.16f),
                                selectedTextColor = Purple,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->

        Column(
            Modifier
                .fillMaxSize()
                .background(Bg)
                .padding(padding)
                .padding(horizontal = 20.dp)
        ) {

            Spacer(Modifier.height(22.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(
                        "MUSICBOX",
                        color = Purple,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 4.sp
                    )

                    Spacer(Modifier.height(5.dp))

                    Text(
                        when (selectedTab) {
                            "Избранное" -> "Избранное"
                            "Плейлисты" -> openedPlaylist?.name ?: "Твои подборки"
                            "Сейчас играет" -> "Сейчас играет"
                            else -> "Твоя музыка"
                        },
                        color = White,
                        fontSize = 29.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Box(
                    Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(PurpleDark, Purple)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.GraphicEq,
                        null,
                        tint = White,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(Modifier.height(20.dp))

            when (selectedTab) {

                "Плейлисты" -> {

                    if (openedPlaylist == null) {

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "Твои музыкальные подборки",
                                    color = Muted,
                                    fontSize = 13.sp
                                )
                                Text(
                                    "${playlists.size} плейлистов",
                                    color = Purple,
                                    fontSize = 12.sp
                                )
                            }

                            FilledTonalButton(
                                onClick = {
                                    showCreatePlaylist = true
                                },
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = Purple.copy(alpha = 0.18f),
                                    contentColor = Purple
                                ),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.Add, null)
                                Text(" Создать")
                            }
                        }

                        Spacer(Modifier.height(17.dp))

                        if (playlists.isEmpty()) {
                            EmptyState(
                                "Пока нет плейлистов",
                                "Создай первую подборку и добавляй в неё музыку"
                            )
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(bottom = 15.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(playlists, key = { it.id }) { playlist ->
                                    PlaylistRow(
                                        name = playlist.name,
                                        onClick = {
                                            selectedPlaylist = playlist
                                        }
                                    )
                                }
                            }
                        }

                    } else {

                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = {
                                    selectedPlaylist = null
                                }
                            ) {
                                Icon(
                                    Icons.Default.ArrowBack,
                                    "Назад",
                                    tint = White
                                )
                            }

                            Text(
                                openedPlaylist.name,
                                color = White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )

                            TextButton(
                                onClick = {
                                    selectedTab = "Библиотека"
                                    selectedPlaylist = null
                                }
                            ) {
                                Text("Добавить", color = Purple)
                            }
                        }

                        Spacer(Modifier.height(12.dp))

                        if (playlistSongs.isEmpty()) {
                            EmptyState(
                                "Плейлист пуст",
                                "Добавь сюда песни из библиотеки"
                            )
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(bottom = 15.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(playlistSongs, key = { it.id }) { song ->
                                    SongRow(
                                        song = song,
                                        isFavorite = favorites.any { it.id == song.id },
                                        onClick = {
                                            activeQueue.clear()
                                            activeQueue.addAll(playlistSongs)

                                            val index = playlistSongs.indexOfFirst {
                                                it.id == song.id
                                            }

                                            currentIndex = index
                                            controller.play(playlistSongs, index)

                                            (context as? ComponentActivity)
                                                ?.lifecycleScope?.launch {
                                                    dao.markPlayed(
                                                        song.id,
                                                        System.currentTimeMillis()
                                                    )
                                                }
                                        },
                                        onFavorite = { favorite ->
                                            (context as? ComponentActivity)
                                                ?.lifecycleScope?.launch {
                                                    dao.setFavorite(song.id, favorite)
                                                }
                                        },
                                        onAdd = {
                                            showAddToPlaylist = song
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                "Сейчас играет" -> {

                    if (currentSong == null) {
                        EmptyState(
                            "Ничего не играет",
                            "Выбери композицию в своей библиотеке"
                        )
                    } else {
                        NowPlaying(
                            song = currentSong,
                            playing = isPlaying,
                            position = position,
                            duration = duration,
                            onPlayPause = {
                                if (isPlaying) controller.player.pause()
                                else controller.player.play()
                            },
                            onPrevious = {
                                controller.player.seekToPreviousMediaItem()
                            },
                            onNext = {
                                controller.player.seekToNextMediaItem()
                            },
                            onSeek = {
                                controller.player.seekTo(it)
                            }
                        )
                    }
                }

                else -> {

                    if (selectedTab == "Библиотека") {
                        LibraryBanner(
                            songCount = songs.size,
                            onRefresh = {
                                scanLibrary()
                            }
                        )
                        Spacer(Modifier.height(18.dp))
                    }

                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = {
                            Text(
                                "Найти трек или исполнителя",
                                color = Muted,
                                fontSize = 13.sp
                            )
                        },
                        leadingIcon = {
                            Icon(
                                Icons.Default.Search,
                                null,
                                tint = Purple
                            )
                        },
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(onClick = { query = "" }) {
                                    Icon(
                                        Icons.Default.Close,
                                        null,
                                        tint = Muted
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(17.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Purple,
                            unfocusedBorderColor = SurfaceLight,
                            focusedTextColor = White,
                            unfocusedTextColor = White,
                            cursorColor = Purple,
                            focusedContainerColor = SurfaceDark,
                            unfocusedContainerColor = SurfaceDark
                        )
                    )

                    Spacer(Modifier.height(18.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (selectedTab == "Избранное") {
                                    "Твои любимые треки"
                                } else {
                                    "Все композиции"
                                },
                                color = White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                "${visibleSongs.size} композиций",
                                color = Muted,
                                fontSize = 11.sp
                            )
                        }

                        IconButton(onClick = { scanLibrary() }) {
                            Icon(
                                Icons.Default.Refresh,
                                "Обновить",
                                tint = Purple
                            )
                        }
                    }

                    Spacer(Modifier.height(7.dp))

                    if (songs.isEmpty()) {
                        EmptyState(
                            "Музыка пока не добавлена",
                            scanMessage
                        )
                    } else if (visibleSongs.isEmpty()) {
                        EmptyState(
                            "Ничего не найдено",
                            "Попробуй изменить поисковый запрос"
                        )
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(bottom = 15.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(visibleSongs, key = { it.id }) { song ->
                                SongRow(
                                    song = song,
                                    isFavorite = favorites.any { it.id == song.id },
                                    onClick = {
                                        val index = songs.indexOfFirst {
                                            it.id == song.id
                                        }

                                        activeQueue.clear()
                                        activeQueue.addAll(songs)

                                        currentIndex = index
                                        controller.play(songs, index)

                                        (context as? ComponentActivity)
                                            ?.lifecycleScope?.launch {
                                                dao.markPlayed(
                                                    song.id,
                                                    System.currentTimeMillis()
                                                )
                                            }
                                    },
                                    onFavorite = { favorite ->
                                        (context as? ComponentActivity)
                                            ?.lifecycleScope?.launch {
                                                dao.setFavorite(song.id, favorite)
                                            }
                                    },
                                    onAdd = {
                                        showAddToPlaylist = song
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreatePlaylist) {
        AlertDialog(
            onDismissRequest = {
                showCreatePlaylist = false
            },
            containerColor = SurfaceDark,
            title = {
                Text("Новый плейлист", color = White)
            },
            text = {
                OutlinedTextField(
                    value = playlistName,
                    onValueChange = { playlistName = it },
                    label = { Text("Название") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (playlistName.isNotBlank()) {
                            (context as? ComponentActivity)
                                ?.lifecycleScope?.launch {
                                    dao.createPlaylist(
                                        PlaylistEntity(
                                            name = playlistName.trim()
                                        )
                                    )
                                }
                        }

                        playlistName = ""
                        showCreatePlaylist = false
                    }
                ) {
                    Text("Создать", color = Purple)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        showCreatePlaylist = false
                    }
                ) {
                    Text("Отмена", color = Muted)
                }
            }
        )
    }

    showAddToPlaylist?.let { song ->
        AlertDialog(
            onDismissRequest = {
                showAddToPlaylist = null
            },
            containerColor = SurfaceDark,
            title = {
                Text("Добавить в плейлист", color = White)
            },
            text = {
                if (playlists.isEmpty()) {
                    Text(
                        "Сначала создай плейлист во вкладке «Плейлисты»",
                        color = Muted
                    )
                } else {
                    Column {
                        playlists.forEach { playlist ->
                            TextButton(
                                onClick = {
                                    (context as? ComponentActivity)
                                        ?.lifecycleScope?.launch {
                                            dao.addSongToPlaylist(
                                                PlaylistSongCrossRef(
                                                    playlist.id,
                                                    song.id
                                                )
                                            )
                                        }

                                    showAddToPlaylist = null
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(
                                    Icons.Default.QueueMusic,
                                    null,
                                    tint = Purple
                                )
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    playlist.name,
                                    color = White
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { showAddToPlaylist = null }
                ) {
                    Text("Закрыть", color = Purple)
                }
            }
        )
    }
}

@Composable
private fun LibraryBanner(
    songCount: Int,
    onRefresh: () -> Unit
) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(23.dp))
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0xFF7046C7),
                        Color(0xFF442B79),
                        Color(0xFF241A39)
                    )
                )
            )
            .padding(18.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Твоя музыка.",
                    color = White,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(Modifier.height(5.dp))

                Text(
                    "Всё любимое в одном месте",
                    color = White.copy(alpha = 0.8f),
                    fontSize = 12.sp
                )

                Spacer(Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.MusicNote,
                        null,
                        tint = White,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(Modifier.width(5.dp))
                    Text(
                        "$songCount треков",
                        color = White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Box(
                Modifier
                    .size(75.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.13f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Headphones,
                    null,
                    tint = White,
                    modifier = Modifier.size(48.dp)
                )
            }
        }
    }
}

@Composable
private fun SongRow(
    song: SongEntity,
    isFavorite: Boolean,
    onClick: () -> Unit,
    onFavorite: (Boolean) -> Unit,
    onAdd: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(SurfaceDark)
            .clickable(onClick = onClick)
            .padding(11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(53.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFFB16CEA),
                            Color(0xFF5B3A9E),
                            Color(0xFF29213F)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.MusicNote,
                null,
                tint = White,
                modifier = Modifier.size(28.dp)
            )
        }

        Spacer(Modifier.width(12.dp))

        Column(Modifier.weight(1f)) {
            Text(
                song.title,
                color = White,
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(Modifier.height(4.dp))

            Text(
                song.artist,
                color = Muted,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        IconButton(onClick = { onFavorite(!isFavorite) }) {
            Icon(
                if (isFavorite) Icons.Default.Favorite
                else Icons.Default.FavoriteBorder,
                null,
                tint = if (isFavorite) Purple else Muted
            )
        }

        IconButton(onClick = onAdd) {
            Icon(
                Icons.Default.MoreVert,
                null,
                tint = Muted
            )
        }
    }
}

@Composable
private fun MiniPlayer(
    song: SongEntity,
    playing: Boolean,
    position: Long,
    duration: Long,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onOpen: () -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 5.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(SurfaceLight)
            .clickable(onClick = onOpen)
            .padding(horizontal = 13.dp, vertical = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(43.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(PurpleDark, Purple)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Album,
                    null,
                    tint = White,
                    modifier = Modifier.size(25.dp)
                )
            }

            Spacer(Modifier.width(11.dp))

            Column(Modifier.weight(1f)) {
                Text(
                    song.title,
                    color = White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    song.artist,
                    color = Muted,
                    fontSize = 11.sp,
                    maxLines = 1
                )
            }

            IconButton(onClick = onPlayPause) {
                Icon(
                    if (playing) Icons.Default.Pause
                    else Icons.Default.PlayArrow,
                    null,
                    tint = White
                )
            }

            IconButton(onClick = onNext) {
                Icon(
                    Icons.Default.SkipNext,
                    null,
                    tint = White
                )
            }
        }

        LinearProgressIndicator(
            progress = {
                if (duration > 0L) {
                    (position.toFloat() / duration).coerceIn(0f, 1f)
                } else {
                    0f
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(3.dp)
                .clip(CircleShape),
            color = Purple,
            trackColor = Color(0xFF514568)
        )
    }
}

@Composable
private fun NowPlaying(
    song: SongEntity,
    playing: Boolean,
    position: Long,
    duration: Long,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSeek: (Long) -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(top = 12.dp, bottom = 15.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.GraphicEq,
                null,
                tint = Purple,
                modifier = Modifier.size(22.dp)
            )

            Spacer(Modifier.width(8.dp))

            Text(
                "СЕЙЧАС ИГРАЕТ",
                color = Muted,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
        }

        Spacer(Modifier.height(22.dp))

        Box(
            Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 18.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFFB16CEA),
                            Color(0xFF7046C7),
                            Color(0xFF211832)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.MusicNote,
                null,
                tint = White.copy(alpha = 0.95f),
                modifier = Modifier.size(125.dp)
            )
        }

        Spacer(Modifier.height(25.dp))

        Text(
            song.title,
            color = White,
            fontSize = 23.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Spacer(Modifier.height(6.dp))

        Text(
            song.artist,
            color = Muted,
            fontSize = 15.sp,
            maxLines = 1
        )

        Spacer(Modifier.height(22.dp))

        Slider(
            value = if (duration > 0L) {
                position.toFloat().coerceIn(0f, duration.toFloat())
            } else {
                0f
            },
            onValueChange = {
                onSeek(it.toLong())
            },
            valueRange = 0f..duration.coerceAtLeast(1L).toFloat(),
            colors = SliderDefaults.colors(
                thumbColor = Purple,
                activeTrackColor = Purple,
                inactiveTrackColor = SurfaceLight
            )
        )

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                formatTime(position),
                color = Muted,
                fontSize = 11.sp
            )

            Text(
                formatTime(duration),
                color = Muted,
                fontSize = 11.sp
            )
        }

        Spacer(Modifier.height(22.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(27.dp)
        ) {
            IconButton(
                onClick = onPrevious,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    Icons.Default.SkipPrevious,
                    null,
                    tint = White,
                    modifier = Modifier.size(34.dp)
                )
            }

            IconButton(
                onClick = onPlayPause,
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(Purple, PurpleDark)
                        )
                    )
            ) {
                Icon(
                    if (playing) Icons.Default.Pause
                    else Icons.Default.PlayArrow,
                    null,
                    tint = White,
                    modifier = Modifier.size(39.dp)
                )
            }

            IconButton(
                onClick = onNext,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    Icons.Default.SkipNext,
                    null,
                    tint = White,
                    modifier = Modifier.size(34.dp)
                )
            }
        }

        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun PlaylistRow(
    name: String,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(SurfaceDark)
            .clickable(onClick = onClick)
            .padding(13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(58.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFFB16CEA),
                            Color(0xFF6545A5),
                            Color(0xFF29213F)
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.QueueMusic,
                null,
                tint = White,
                modifier = Modifier.size(30.dp)
            )
        }

        Spacer(Modifier.width(14.dp))

        Text(
            name,
            color = White,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            modifier = Modifier.weight(1f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Icon(
            Icons.Default.ChevronRight,
            null,
            tint = Muted
        )
    }
}

@Composable
private fun EmptyState(
    title: String,
    description: String
) {
    Column(
        Modifier
            .fillMaxWidth()
            .padding(top = 65.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(90.dp)
                .clip(CircleShape)
                .background(Purple.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.LibraryMusic,
                null,
                tint = Purple,
                modifier = Modifier.size(43.dp)
            )
        }

        Spacer(Modifier.height(18.dp))

        Text(
            title,
            color = White,
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(Modifier.height(7.dp))

        Text(
            description,
            color = Muted,
            fontSize = 13.sp
        )
    }
}

private fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0L)
    return "%d:%02d".format(total / 60, total % 60)
}
