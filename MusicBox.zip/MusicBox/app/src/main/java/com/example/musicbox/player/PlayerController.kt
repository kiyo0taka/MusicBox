package com.example.musicbox.player

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import com.example.musicbox.data.SongEntity

class PlayerController(context: Context) {
    val player: ExoPlayer = ExoPlayer.Builder(context).build()
    fun play(songs: List<SongEntity>, index: Int) {
        if (songs.isEmpty()) return
        player.setMediaItems(songs.map { MediaItem.fromUri(it.uri) }, index.coerceIn(songs.indices), 0L)
        player.prepare()
        player.play()
    }
    fun release() = player.release()
}
